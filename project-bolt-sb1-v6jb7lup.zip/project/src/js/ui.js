import { LiteApp, LiteAppsManager } from './liteApps.js';
import { downloadProjectAsZip } from './zipUtils.js';

export class UI {
  constructor() {
    this.manager = new LiteAppsManager();
    this.manager.loadApps();
  }

  init() {
    this.renderApps();
    this.setupEventListeners();
  }

  renderApps() {
    const appsContainer = document.getElementById('apps-container');
    appsContainer.innerHTML = '';

    this.manager.getApps().forEach(app => {
      const appElement = this.createAppElement(app);
      appsContainer.appendChild(appElement);
    });
  }

  createAppElement(app) {
    const div = document.createElement('div');
    div.className = 'app-card';
    div.innerHTML = `
      <img src="${app.icon}" alt="${app.name}" class="app-icon">
      <h3>${app.name}</h3>
      <div class="app-actions">
        <button onclick="window.open('${app.url}', '_blank')">Open</button>
        <button onclick="removeApp('${app.name}')" class="delete">Remove</button>
      </div>
    `;
    return div;
  }

  setupEventListeners() {
    const addForm = document.getElementById('add-app-form');
    addForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('app-name').value;
      const url = document.getElementById('app-url').value;
      const icon = document.getElementById('app-icon').value;

      const newApp = new LiteApp(name, url, icon);
      this.manager.addApp(newApp);
      this.renderApps();
      addForm.reset();
    });

    window.removeApp = (appName) => {
      this.manager.removeApp(appName);
      this.renderApps();
    };

    const downloadButton = document.getElementById('download-project');
    if (downloadButton) {
      downloadButton.addEventListener('click', async () => {
        try {
          await downloadProjectAsZip('sb1-v6jb7lup');
        } catch (error) {
          alert('Failed to download project. Please try again.');
        }
      });
    }
  }
}