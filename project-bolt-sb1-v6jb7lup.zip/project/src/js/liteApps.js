export class LiteApp {
  constructor(name, url, icon) {
    this.name = name;
    this.url = url;
    this.icon = icon;
  }
}

export class LiteAppsManager {
  constructor() {
    this.apps = [];
  }

  addApp(app) {
    this.apps.push(app);
    this.saveApps();
  }

  removeApp(appName) {
    this.apps = this.apps.filter(app => app.name !== appName);
    this.saveApps();
  }

  getApps() {
    return this.apps;
  }

  saveApps() {
    localStorage.setItem('liteApps', JSON.stringify(this.apps));
  }

  loadApps() {
    const savedApps = localStorage.getItem('liteApps');
    if (savedApps) {
      const parsedApps = JSON.parse(savedApps);
      this.apps = parsedApps.map(app => new LiteApp(app.name, app.url, app.icon));
    }
  }
}