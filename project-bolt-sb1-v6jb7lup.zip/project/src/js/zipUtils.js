export async function downloadProjectAsZip(projectId) {
  try {
    const response = await fetch(`/api/projects/${projectId}/download`);
    if (!response.ok) {
      throw new Error('Failed to download project');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectId}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error downloading project:', error);
    throw error;
  }
}